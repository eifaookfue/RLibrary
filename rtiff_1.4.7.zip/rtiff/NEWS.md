# rtiff 1.4.6

* Added a `NEWS.md` file to track changes to the package.
* Changes configure.in to configure.ac
* Registers native routines

# rtiff 1.4.7

* Return R_NilValue instead of void where applicable
* Updated the C interface for updateDescription for libtiff 4.0+
* Use inherits() rather than class()
