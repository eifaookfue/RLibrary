# repurrrsive 1.0.0

* `discog` is a new dataset, containing Sharla Gelfand's discography, inspired
  by <https://sharla.party/posts/discog-purrr/> and used in a new tidyr
  vignette on rectangling.

# repurrrsive 0.1.0

* Initial CRAN release
