library(testthat)
library(repurrrsive)

if (requireNamespace("rprojroot")) {
  test_check("repurrrsive")
}
