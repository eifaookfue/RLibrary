#' @importFrom tibble tibble
#' @details Read more at <https://github.com/jennybc/repurrrsive#readme>.
"_PACKAGE"
