#' @keywords internal
#' @inherit summary.bench_mark examples
"_PACKAGE"
